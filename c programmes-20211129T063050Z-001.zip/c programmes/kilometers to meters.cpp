#include<stdio.h>
int main()
{
    int k;
    printf("enter the value of kilometers" , k);
    scanf("%d" ,&k);
    float m;
    m=k*1000;
    printf("the value of meters in kilometes is %f" , m);
    return 0;
    
}
