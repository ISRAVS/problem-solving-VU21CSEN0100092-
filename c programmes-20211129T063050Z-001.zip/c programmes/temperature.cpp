#include<stdio.h>
int main()
{
 int c,k;
 printf("enter the temperature in celcius" , c);
 scanf("%d" ,&c);
 k=c+273;
 printf("the temp in kelvin is %d" , k);
 return 0;
}
