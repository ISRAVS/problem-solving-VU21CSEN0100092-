#include<stdio.h>
int main()
{
    int dividend,divisor,quotient;
    printf("enter the value of divisor" , divisor);
    scanf("%d" ,& divisor);
    printf("enter the value of quotient" , quotient );
    scanf("%d" ,& quotient );
    dividend=divisor*quotient;
    printf("the value of dividend is %d" , dividend );
    return 0;
}
