#include<stdio.h>
int main()
{
    int r;
    printf("enter the value of radius " , r);
    scanf("%d" , &r);
    float area;
    area =3.14*r*r;
    printf("the area of circle is %f" , area);
    return 0;
}
