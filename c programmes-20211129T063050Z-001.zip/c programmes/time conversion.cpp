#include<stdio.h>
int main()
{
    int m,s;
    printf("enter the value of minutes" , m);
    scanf("%d" ,&m);
    s=m*60;
    printf("the value of seconds is %d" , s);
    return 0;
}
